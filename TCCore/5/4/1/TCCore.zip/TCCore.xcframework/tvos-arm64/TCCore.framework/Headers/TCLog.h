//
//  TCLog.h
//  TagCommander
//
//  Created by Jean-Julien ZEIL on 10/02/14.
//  Copyright (c) 2014 TagCommander. All rights reserved.
//

#ifndef TagCommander_TCLog_h
#define TagCommander_TCLog_h

typedef enum TCLogLevel
{
    TCLogLevel_None,
    TCLogLevel_Assert,
    TCLogLevel_Error,
    TCLogLevel_Warn,
    TCLogLevel_Info,
    TCLogLevel_Debug,
    TCLogLevel_Verbose,
} TCLogLevel;

#endif
