//
//  TCServerSideUtils.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 02/08/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef TCServerSideUtils_h
#define TCServerSideUtils_h
#if __has_include(<TCServerSide_noIDFA/TCEvent.h>)
#import <TCServerSide_noIDFA/TCEvent.h>
#else
#import <TCServerSide/TCEvent.h>
#endif

@interface TCServerSideUtils : NSObject

+ (NSDictionary *) eventPropertiesToDictionary: (TCEvent *) event;
@end

#endif /* TCServerSideUtils_h */
