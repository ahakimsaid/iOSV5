//
//  TCEventPropertiesNames.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef schemes_TCEventPropertiesNames_h
#define schemes_TCEventPropertiesNames_h

#import <Foundation/Foundation.h>

@interface TCEventPropertiesNames : NSObject

    // Generic
extern NSString *const TC_ID;

    // All events
extern NSString *const TCE_EVENT;
extern NSString *const TCE_EVENTID;
extern NSString *const TC_EVENTTIMESTAMP;

    // Event specific
extern NSString *const TCE_PAYMENTMETHOD;
extern NSString *const TCE_COUPON;
extern NSString *const TCE_CURRENCY;
extern NSString *const TCE_REVENUE;
extern NSString *const TCE_VALUE;
extern NSString *const TCE_ITEMS;
extern NSString *const TCE_SHIPPINGTIER;
extern NSString *const TCE_SHIPPINGAMOUNT;
extern NSString *const TCE_TAXAMOUNT;
extern NSString *const TCE_METHOD;
extern NSString *const TCE_TYPE;
extern NSString *const TCE_NAME;
extern NSString *const TCE_TITLE;
extern NSString *const TCE_URL;
extern NSString *const TCE_PATH;
extern NSString *const TCE_REFERRER;
extern NSString *const TCE_STATUS;
extern NSString *const TCE_SEARCHTERM;
extern NSString *const TCE_CONTENTTYPE;
extern NSString *const TCE_ITEMID;
extern NSString *const TCE_ITEMLISTNAME;
extern NSString *const TCE_PAGENAME;
extern NSString *const TCE_PAGETYPE;

    // Item
extern NSString *const TCI_PRODUCT;
extern NSString *const TCI_VARIANT;
extern NSString *const TCI_LISTPOSITION;
extern NSString *const TCI_DISCOUNT;
extern NSString *const TCI_QUANTITY;
extern NSString *const TCI_AFFILIATION;

    // Product
extern NSString *const TCP_PRICE;
extern NSString *const TCP_BRAND;
extern NSString *const TCP_NAME;
extern NSString *const TCP_COLORS;
extern NSString *const TCP_SIZE;
extern NSString *const TCP_CATEGORY_N;

// Lifecycle
extern NSString *const TCL_LIFECYCLE;
extern NSString *const TCL_SESSION_ID;
extern NSString *const TCL_NEW_SESSION;
extern NSString *const TCL_SESSION_DURATION;
extern NSString *const TCL_CURRENT_SESSION;
extern NSString *const TCL_VISIT_NUMBER;
extern NSString *const TCL_CURRENT_VISIT;
extern NSString *const TCL_CUR_VER_FIRST_VISIT;
extern NSString *const TCL_SESSION_NUMBER;
extern NSString *const TCL_FIRST_VISIT;
extern NSString *const TCL_LAST_VISIT;
extern NSString *const TCL_LAST_CALL;
extern NSString *const TCL_LAST_SESSION_START;
extern NSString *const TCL_LAST_SESSION_LAST_HIT;
extern NSString *const TCL_FOREGROUND_TRANSITIONS;
extern NSString *const TCL_FOREGROUND_TIME;
extern NSString *const TCL_BACKGROUND_TIME;
extern NSString *const TCL_FIRST_EXECUTE;
extern NSString *const TCL_IS_FIRST_VISIT;

    // App
extern NSString *const TCA_APP;
extern NSString *const TCA_NAME;
extern NSString *const TCA_VERSION;
extern NSString *const TCA_BUILD;
extern NSString *const TCA_NAMESPACE;
extern NSString *const TCA_COREVERSION;
extern NSString *const TCA_SERVERSIDEVERSION;
extern NSString *const TCA_CONSENTVERSION;

    // Video Events

extern NSString *const TCV_VIDEO_SESSION_ID;
extern NSString *const TCV_CONTENT_ASSET_ID;
extern NSString *const TCV_CONTENT_POD_ID;
extern NSString *const TCV_AD_ASSET_ID;
extern NSString *const TCV_AD_POD_ID;
extern NSString *const TCV_AD_TYPE;
extern NSString *const TCV_POD_POSITION;
extern NSString *const TCV_CURSOR_POSITION;
extern NSString *const TCV_SEEK_POSITION;
extern NSString *const TCV_TOTAL_LENGTH;
extern NSString *const TCV_POD_LENGTH;
extern NSString *const TCV_BITRATE;
extern NSString *const TCV_FRAMERATE;
extern NSString *const TCV_VIDEO_PLAYER;
extern NSString *const TCV_SOUND;
extern NSString *const TCV_FULL_SCREEN;
extern NSString *const TCV_AD_ENABLED;
extern NSString *const TCV_IMAGE_QUALITY;
extern NSString *const TCV_INTERRUPTION_METHOD;
extern NSString *const TCV_LIVESTREAM;
extern NSString *const TCV_VIDEO_TITLE;
extern NSString *const TCV_VIDEO_DESCRIPTION;
extern NSString *const TCV_KEYWORDS;
extern NSString *const TCV_SEASON;
extern NSString *const TCV_EPISODE;
extern NSString *const TCV_VIDEO_CATEGORY;
extern NSString *const TCV_PROGRAM;
extern NSString *const TCV_PUBLISHER;
extern NSString *const TCV_CHANNEL;
extern NSString *const TCV_FULL_EPISODE;
extern NSString *const TCV_AIRDATE;
extern NSString *const TCV_LOAD_TYPE;
extern NSString *const TCV_AD_QUARTILE;

@end

#endif
