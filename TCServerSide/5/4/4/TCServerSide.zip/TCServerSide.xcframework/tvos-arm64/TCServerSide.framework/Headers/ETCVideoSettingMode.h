//
//  Header.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef Header_h
#define Header_h

typedef enum ETCVideoSettingMode
{
    video_volume,
    video_speed,
    video_subtitle_on,
    video_subtitle_off,
    video_fullscreen_on,
    video_fullscreen_off,
    video_quality,
    video_share
} ETCVideoSettingMode;
#endif /* Header_h */

extern NSString * const ETCVideoSettingMode_toString[];
