//
//  TCVideoEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef TCVideoEvent_h
#define TCVideoEvent_h
#if __has_include(<TCServerSide_noIDFA/TCEvent.h>)
#import <TCServerSide_noIDFA/TCEvent.h>
#else
#import <TCServerSide/TCEvent.h>
#endif

@interface TCVideoEvent : TCEvent

@property (nonatomic, retain) NSString* videoSessionID;
@property (nonatomic, retain) NSDecimalNumber* cursorPosition;
@property (nonatomic, retain) NSDecimalNumber* totalLength;
@property (nonatomic, retain) NSString* videoTitle;
@property (nonatomic, retain) NSString* publisher;

@end
#endif /* TCVideoEvent_h */
