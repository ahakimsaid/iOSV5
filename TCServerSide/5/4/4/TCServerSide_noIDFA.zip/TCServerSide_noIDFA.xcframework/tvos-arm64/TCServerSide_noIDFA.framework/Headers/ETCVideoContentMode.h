//
//  ETCVideoContentMode.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef ETCVideoContentMode_h
#define ETCVideoContentMode_h

typedef enum ETCVideoContentMode
{
    video_content_start,
    video_content_playing,
    video_content_quarter_reached,
    video_content_complete
} ETCVideoContentMode;

extern NSString * const ETCVideoContentMode_toString[];

#endif /* ETCVideoContentMode_h */
