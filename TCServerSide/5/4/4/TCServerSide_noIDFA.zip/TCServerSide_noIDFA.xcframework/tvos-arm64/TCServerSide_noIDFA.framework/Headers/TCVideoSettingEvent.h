//
//  TCVideoSettingEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 31/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef TCVideoSettingEvent_h
#define TCVideoSettingEvent_h

#if __has_include(<TCServerSide_noIDFA/TCVideoEvent.h>)
#import <TCServerSide_noIDFA/TCVideoEvent.h>
#import <TCServerSide_noIDFA/ETCVideoSettingMode.h>
#else
#import <TCServerSide/TCVideoEvent.h>
#import <TCServerSide/ETCVideoSettingMode.h>
#endif

@interface TCVideoSettingEvent : TCVideoEvent

- (instancetype) initWithMode: (ETCVideoSettingMode) mode andSessionId: (NSString *) sessionID;

@property (nonatomic, retain) NSString* contentPodID;
@property (nonatomic, retain) NSString* contentAssetID;
@property (nonatomic, retain) NSString* adAssetID;
@property (nonatomic, retain) NSString* adPodID;
@property (nonatomic, retain) NSString* adType;
@property (nonatomic, retain) NSString* videoDescription;
@property (nonatomic, retain) NSMutableArray* keywords;
@property (nonatomic, retain) NSString* season;
@property (nonatomic, retain) NSString* episode;
@property (nonatomic, retain) NSString* videoCategory;
@property (nonatomic, retain) NSString* program;
@property (nonatomic, retain) NSString* channel;
@property BOOL fullEpisode;
@property BOOL livestream;
@property (nonatomic, retain) NSString* airdate;
@property (nonatomic, retain) NSDecimalNumber* bitrate;
@property (nonatomic, retain) NSDecimalNumber* framerate;
@property (nonatomic, retain) NSDecimalNumber* sound;
@property BOOL fullScreen;
@property BOOL adEnabled;
@property (nonatomic, retain) NSString* imageQuality;


@end

#endif /* TCVideoSettingEvent_h */
