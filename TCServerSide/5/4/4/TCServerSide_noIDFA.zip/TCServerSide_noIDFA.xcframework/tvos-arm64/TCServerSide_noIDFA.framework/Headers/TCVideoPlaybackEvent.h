//
//  TCVideoPlaybackEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 31/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef TCVideoPlaybackEvent_h
#define TCVideoPlaybackEvent_h
#if __has_include(<TCServerSide_noIDFA/TCVideoEvent.h>)
#import <TCServerSide_noIDFA/TCVideoEvent.h>
#import <TCServerSide_noIDFA/ETCVideoPlaybackMode.h>
#else
#import <TCServerSide/TCVideoEvent.h>
#import <TCServerSide/ETCVideoPlaybackMode.h>
#endif

@interface TCVideoPlaybackEvent : TCVideoEvent

- (instancetype) initWithMode: (ETCVideoPlaybackMode) mode andSessionId: (NSString *) sessionID;

@property (nonatomic, retain) NSMutableArray* contentAssetID;
@property (nonatomic, retain) NSMutableArray* contentPodID;
@property (nonatomic, retain) NSMutableArray* adAssetID;
@property (nonatomic, retain) NSMutableArray* adPodID;
@property (nonatomic, retain) NSString* adtype;
@property (nonatomic, retain) NSDecimalNumber* seekPosition;
@property (nonatomic, retain) NSDecimalNumber* bitrate;
@property (nonatomic, retain) NSDecimalNumber* framerate;
@property (nonatomic, retain) NSString* videoPlayer;
@property (nonatomic, retain) NSDecimalNumber* sound;
@property BOOL fullScreen;
@property BOOL adEnabled;
@property (nonatomic, retain) NSString* imageQuality;
@property (nonatomic, retain) NSString* interruptionMethod;
@property BOOL livestream;
@property (nonatomic, retain) NSString* videoCategory;

@end


#endif /* TCVideoPlaybackEvent_h */
